package OmniBOT;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

public class ButtonPanel extends JPanel {
	
	public ButtonPanel(){
		super();
		this.setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
		this.add(new JButton("Calibrate compass"));
		this.add(new JButton("Go to Target"));
		this.add(new JButton("Make a 360"));
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

package OmniBOT;

import java.awt.BorderLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.highgui.VideoCapture;
import org.opencv.imgproc.Imgproc;

import lejos.hardware.Sound;
import lejos.hardware.lcd.TextLCD;
import lejos.remote.ev3.RMIRegulatedMotor;
import lejos.remote.ev3.RemoteEV3;
import lejos.utility.Delay;

public class OmniBOTControl {
	public static void main(String[] args) {
		/* OLD CODE
		 * RemoteEV3 ev3 = null; try { ev3 = new RemoteEV3("10.0.1.1"); } catch
		 * (Exception e1) { // TODO Auto-generated catch block
		 * e1.printStackTrace(); } Sound.beep(); Sound.beep(); TextLCD lcd =
		 * ev3.getTextLCD(); ev3.setDefault(); lcd.clear();
		 * lcd.drawString("Connected", 0, 1); RMIRegulatedMotor a =
		 * ev3.createRegulatedMotor("A", 'N'); RMIRegulatedMotor b =
		 * ev3.createRegulatedMotor("B", 'N'); RMIRegulatedMotor c =
		 * ev3.createRegulatedMotor("C", 'N'); double[] motorSpeeds = new
		 * double[3]; // a,b,c double[] cartSpeeds = new double[3]; // Vx,Vy,Rz
		 * double[][] transformation1 = { { 0, 27.7778, -1.2639 }, { 24.0563,
		 * -13.8889, -1.2639 }, { -24.0563, -13.8889, -1.2639 } };
		 */

		// Load the native library.
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		
		//Create Interface
		String window_name = "OmniBOT - Computer Vision Controlled Robot";
		JFrame frame = new JFrame(window_name);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 400);
		Processor my_processor = new Processor();
		My_Panel my_panel = new My_Panel();
		ButtonPanel buttonPanel = new ButtonPanel();
		frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.PAGE_AXIS));
		frame.add(my_panel);
		frame.add(buttonPanel);
		frame.setVisible(true);
		//Read the video stream
		Mat webcam_image = new Mat();
		VideoCapture capture = new VideoCapture(0);

		// If VideoCapture is opened, start looping
		if (capture.isOpened()) {
			
			//Set frame size
			capture.read(webcam_image);
			Size size = new Size(webcam_image.size().width / 2,
					webcam_image.size().height / 2);
			Imgproc.resize(webcam_image, webcam_image, size);
			frame.setSize(webcam_image.width() + 40,
					webcam_image.height() + 65);
			//Loop time
			while (true) {
				capture.read(webcam_image);
				double fps = capture.get(5);
				size = new Size(webcam_image.size().width / 2,
						webcam_image.size().height / 2);
				Imgproc.resize(webcam_image, webcam_image, size);
				if (!webcam_image.empty()) {
					//detectRedCircle and save to webcam_image
					webcam_image = my_processor.detectRedCircle(webcam_image);
					System.out.println(my_processor.redCoordinates);
					//Display the image
					my_panel.MatToBufferedImage(webcam_image); 
					my_panel.repaint();
				} else {
					System.out.println(" --(!) No captured frame -- Break!");
					break;
				}
			}
		}
		return;
		/*
		 * try { a.close(); b.close(); c.close(); } catch (RemoteException e) {
		 * // TODO Auto-generated catch block e.printStackTrace(); }
		 */

	}
}
package OmniBOT;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

public class Processor {
	public Point redCoordinates;

	// Create a constructor method
	public Processor() {
		redCoordinates=new Point();
	}

	public Mat detectRedCircle(Mat inputframe) {
		Mat hsv_image = new Mat();
		Mat returnFrame = new Mat();
		Mat array255 = new Mat(inputframe.height(), inputframe.width(),
				CvType.CV_8UC1);
		array255.setTo(new Scalar(255));
		Mat distance = new Mat(inputframe.height(), inputframe.width(),
				CvType.CV_8UC1);
		List<Mat> lhsv = new ArrayList<Mat>(3);
		Mat circles = new Mat();
		inputframe.copyTo(hsv_image);
		inputframe.copyTo(returnFrame);
		Imgproc.cvtColor(inputframe, hsv_image, Imgproc.COLOR_BGR2HSV);
		Scalar hsv_min = new Scalar(0, 50, 50, 0);
		Scalar hsv_max = new Scalar(15, 255, 255, 0);
		Scalar hsv_min2 = new Scalar(170, 50, 50, 0);
		Scalar hsv_max2 = new Scalar(185, 255, 255, 0);
		Mat thresholded = new Mat();
		Mat thresholded2 = new Mat();
		Core.inRange(hsv_image, hsv_min, hsv_max, thresholded);
		Core.inRange(hsv_image, hsv_min2, hsv_max2, thresholded2);
		Core.bitwise_or(thresholded, thresholded2, thresholded);
		Core.split(hsv_image, lhsv); // We get 3 2D one channel Mats
		Mat S = lhsv.get(1);
		Mat V = lhsv.get(2);
		Core.subtract(array255, S, S);
		Core.subtract(array255, V, V);
		S.convertTo(S, CvType.CV_32F);
		V.convertTo(V, CvType.CV_32F);
		Core.magnitude(S, V, distance);
		Core.inRange(distance, new Scalar(0.0), new Scalar(200.0), thresholded2);
		Core.bitwise_and(thresholded, thresholded2, thresholded);
		Imgproc.GaussianBlur(thresholded, thresholded, new Size(9, 9), 0, 0);
		Imgproc.HoughCircles(thresholded, circles, Imgproc.CV_HOUGH_GRADIENT,
				2, thresholded.height() / 4, 500, 50, 0, 0);

		int rows = circles.rows();
		int elemSize = (int) circles.elemSize(); // Returns 12 (3 * 4bytes in a
		// float)
		float[] data2 = new float[rows * elemSize / 4];
		if (data2.length > 0) {
			circles.get(0, 0, data2); // Points to the first element and reads
			// the whole thing
			// into data2
			for (int i = 0; i < data2.length; i = i + 3) {
				Point center = new Point(data2[i], data2[i + 1]);
				redCoordinates = center;
				Core.ellipse(returnFrame, center, new Size(
						(double) data2[i + 2], (double) data2[i + 2]), 0, 0,
						360, new Scalar(0, 0, 255), 4, 8, 0);
			}
		}
		return returnFrame;
	}
}